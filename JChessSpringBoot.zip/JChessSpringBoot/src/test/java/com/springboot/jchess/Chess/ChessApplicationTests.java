package com.springboot.jchess.Chess;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChessApplicationTests {

	@Test
	void contextLoads() {
	}

}
